from django.apps import AppConfig


class AppProfileConfig(AppConfig):
    name = 'app_profile'
